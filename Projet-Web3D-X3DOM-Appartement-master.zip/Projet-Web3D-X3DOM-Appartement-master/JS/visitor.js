function View(building)
{
    var b = document.getElementById("building");
    b.setAttribute("whichChoice", building);
}